import json
import os

import jinja2
import pandas as pd
import pdfkit
from django.http import JsonResponse, HttpResponse, FileResponse
from rest_framework import status

from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.core.files.base import ContentFile
from .models import PDFModel

import os
import pandas as pd
from django.http import JsonResponse
from rest_framework.decorators import api_view
import requests



def generate_pdf(data):
    data_pdf = {
        "gmail": data["email_id"],
        "percentage": percentage(data),
        "valid_penalties": penalty_key_pair(data)[0],
        "maximum_penalties": penalty_key_pair(data)[1]
    }

    template_loader = jinja2.FileSystemLoader(searchpath="myapp/templates/")
    template_env = jinja2.Environment(loader=template_loader)
    template = template_env.get_template("index.html")
    output_text = template.render(data_pdf)

    with open("index.html", "w") as file:
        file.write(output_text)

    path_to_wkhtmltopdf = r'C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe'
    config = pdfkit.configuration(wkhtmltopdf=path_to_wkhtmltopdf)
    pdf_content = pdfkit.from_file("index.html", False, configuration=config)

    pdf_model = PDFModel()
    path = os.path.join(get_pdf_url(data), "output.pdf")
    # print("path-->",path)
    if os.path.exists(path):
        os.remove(path)
    pdf_model.file.save(path, ContentFile(pdf_content))
    pdf_model.save()
    return path

@api_view(['POST'])
def upload_questions(request):
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return Response({"error": "Invalid JSON"}, status=status.HTTP_400_BAD_REQUEST)

    required_fields = ['user_id', 'email_id', 'question']
    for field in required_fields:
        if field not in data:
            return Response({"error": f"Missing required field: {field}"}, status=status.HTTP_400_BAD_REQUEST)

    questions = data['question']
    for i in range(1, 12):
        question_key = str(i)
        if question_key not in questions:
            return Response({"error": f"Missing question: {question_key}"}, status=status.HTTP_400_BAD_REQUEST)
        if not isinstance(questions[question_key], list):
            return Response({"error": f"Answers for question {question_key} must be a list"},
                            status=status.HTTP_400_BAD_REQUEST)

    return Response({"message": "Questions uploaded successfully",
                     "output": {"percentage": percentage(data), "max_penalty": penalty_key_pair(data)[1],
                                "section": penalty_key_pair(data)[0],
                                "pdf": generate_pdf(data)}},
                    status=status.HTTP_200_OK)


def get_pdf_url(data):
    filepath = os.path.join(os.path.dirname(__file__), 'files', 'users_pdf')
    users = os.listdir(filepath)
    if not data["email_id"] in users:
        path = os.path.join(filepath, data["email_id"])
        os.mkdir(path)
    return os.path.join(filepath, data["email_id"])


def question_choices_with_values(data):
    question_choices_main = {
        1: {'yes': 1, 'no': 2},
        2: {'yes': 1, 'no': 2},
        3: {'yes': 1, 'no': 2},
        4: {'yes': 1, 'no': 2},
        5: {'consent request notice in process': 1, 'explicit opt-in forms': 2,
            'implicit consent through usage': 3, 'consent of guardian on behalf of child': 4,
            'right to withdraw consent': 5, 'correction and erasure of personal data': 6},
        6: {'purpose limitation ': 1, 'lawful purpose': 2, 'consent': 3,
            'legitimate uses, not expressly forbidden by law': 4, 'impact assessment': 5,
            'security prac  tices': 6, 'wrongful loss, wrongful gain': 7},
        7: {'periodic audits ': 1, 'data protection impact assessment ': 2, 'data auditor': 3,
            'data protection officer': 4, 'consent, lawful purpose': 5,
            'internal security audits': 6,
            'external audit': 7, 'reasonable security practices': 8, 'fraud risk management': 9,
            'periodic legal audit': 10, 'pre-implementation, post implementation': 11},
        8: {'copyright infringed': 1, 'patent is a product,  patent is a process': 2,
            'infringment of registered trade mark ': 3, 'piracy of registered design': 4},
        9: {'security controls ': 1, 'conformity assessment ': 2, 'risk management system ': 3,
            'kyc': 4,
            'due diligence report': 5, 'authorised agents confidentiality': 6,
            'privacy of information': 7, 'security practices': 8},
        10: {'web filtering ': 1, 'dlp ( data leakage prevention)': 2, 'use of cryptography': 3,
             'security controls': 4, 'secure pin management': 5,
             'protect cardholder data at terminals, reporting of fraud': 6,
             'in-app notifications': 7,
             'data processor ': 8, 'data auditor': 9, 'secure authentication processes': 10,
             'encrypt card data immediately': 11, 'install tools': 12, 'e-kyc authentication': 13,
             'aadhaar number\n': 14, 'unique identification authority': 15},
        11: {'prohibit subliminal, manipulative ai techniques': 1,
             'block ai scraping facial images': 2,
             'harmful social scoring ai': 3, 'unauthorized access': 4, 'unlawful content': 5,
             'introducing viruses or harmful code': 6}
    }

    li1 = []
    for item in data['question']:
        li2 = []
        for i in data["question"][item]:
            li2.append(question_choices_main[int(item)][i.lower()])
        tup = (item, li2)
        li1.append(tup)
    return li1


def QuestionPenaltyObject(penalty, keyword, penalty_type):
    return (penalty, int(keyword), [int(i) for i in penalty_type.split(',')])


def precomuteQuestionPenalty():
    df = pd.read_csv(
        os.path.join(os.path.dirname(__file__), 'files', 'Copy of Penalty - v.1 - QuestionKeyPenaltyKey Map.csv'))
    listOfQuestions = []
    for index, item in df.iterrows():
        listOfQuestions.append(QuestionPenaltyObject(item['Que no'], item['keyword'], item['Penalty type (key)']))
    return listOfQuestions


def percentage(data):
    question_choices = question_choices_with_values(data)
    allQuestionsPenaltyObjects = precomuteQuestionPenalty()
    totalQuestionsPenaltyObjects = len(allQuestionsPenaltyObjects)
    seenPenaltyObjects = set()
    i = 0
    question_choices_filtered = []

    # convert question_choices to tuple with single elements
    for item in question_choices:
        for i in item[1]:
            question_choices_filtered.append((int(item[0]), i))

    # storing elements in seenPenaltyObjects
    allQuestionsPenaltyObjects_filtered = []
    for item in allQuestionsPenaltyObjects:
        allQuestionsPenaltyObjects_filtered.append(item[:len(item) - 1])

    for element in question_choices_filtered:
        if element in allQuestionsPenaltyObjects_filtered:
            seenPenaltyObjects.add(element)
    print(seenPenaltyObjects, totalQuestionsPenaltyObjects)
    return int(len(seenPenaltyObjects) / totalQuestionsPenaltyObjects * 100)


def get_scenario(data):
    # print("question_choices_with_values")
    return question_choices_with_values(data)


def generate_seenPenaltyObject_allQuestionsPenaltyObject(data):
    question_choices = get_scenario(data)
    allQuestionsPenaltyObjects = precomuteQuestionPenalty()
    totalQuestionsPenaltyObjects = len(allQuestionsPenaltyObjects)
    seenPenaltyObjects = set()
    i = 0
    question_choices_filtered = []

    for item in question_choices:
        for i in item[1]:
            question_choices_filtered.append((item[0], i))

    # storing elements in seenPenaltyObjects
    allQuestionsPenaltyObjects_filtered = []
    for item in allQuestionsPenaltyObjects:
        allQuestionsPenaltyObjects_filtered.append(item[:len(item) - 1])

    for element in question_choices_filtered:
        if element in allQuestionsPenaltyObjects_filtered:
            seenPenaltyObjects.add(element)
    return (seenPenaltyObjects, allQuestionsPenaltyObjects)


def set_of_Penalty_object(data):
    seenPenaltyObjects, allQuestionsPenaltyObjects = generate_seenPenaltyObject_allQuestionsPenaltyObject(data)
    notSelectedKeywords = allQuestionsPenaltyObjects[:]

    validpenaltyset = set()
    for element in seenPenaltyObjects:
        for element1 in allQuestionsPenaltyObjects:
            if element1[:len(element1) - 1] == element:
                notSelectedKeywords.remove(element1)
    for i in notSelectedKeywords:
        for k in i[-1]:
            validpenaltyset.add(k)
    return validpenaltyset


def penalty_section_description():
    df = pd.read_csv(os.path.join(os.path.dirname(__file__), 'files', 'Penalty - v.1 - Penalty Table.csv'))
    section_description = []
    for index, item in df.iterrows():
        section_description.append((item['Section no.'], item['Penalty description'], item['Max Value ( Number )']))
    return section_description


def penalty_key_pair(data):
    validPenaltySet = set_of_Penalty_object(data)
    conversion_of_data = []
    data1 = penalty_section_description()

    # print("data1-->", len(data1))
    maximum_value = 0
    # print("validPenaltySet-->",validPenaltySet)
    for i in validPenaltySet:
        conversion_of_data.append((data1[i - 1][0], data1[i - 1][1]))
        maximum_value += data1[i - 1][2]
    return (conversion_of_data, number_to_words(min(maximum_value, 2500000000)))


def number_to_words(number):
    units = {
        100: "Hundred",
        1000: "Thousand",
        10000: "Ten Thousand",
        100000: "Lakh",
        10000000: "Crore"
    }
    result = []
    for unit in sorted(units.keys(), reverse=True):
        if number >= unit:
            value = number // unit
            result.append("{:} {}".format(value, units[unit]))
            break

    if not result:
        result.append(str(number))
    return ", ".join(result)


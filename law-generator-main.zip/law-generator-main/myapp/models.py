from django.db import models

class PDFModel(models.Model):
    file = models.FileField(max_length=500)
    created_at = models.DateTimeField(auto_now_add=True)


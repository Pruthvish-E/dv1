data = {
    "user_id": "user123",
    "email_id": "user123@example.com",
    "question": {
        "1": ["Yes"],
        "2": ["No"],
        "3": ["Yes"],
        "4": ["Yes"],
        "5": [
            "consent request notice in process",
            "explicit opt-in forms",
            "implicit consent through usage",
            "correction and erasure Of personal data"
        ],
        "6": [],
        "7": [],
        "8": [],
        "9": [],
        "10": [],
        "11": [], }
}
question_choices_main = {1: {'yes': 1, 'no': 2},
                         2: {'yes': 1, 'no': 2},
                         3: {'yes': 1, 'no': 2},
                         4: {'yes': 1, 'no': 2},
                         5: {'consent request notice in process': 1, 'explicit opt-in forms': 2,
                             'implicit consent through usage': 3, 'consent of guardian on behalf of child': 4,
                             'right to withdraw consent': 5, 'correction and erasure of personal data': 6},
                         6: {'purpose limitation ': 1, 'lawful purpose': 2, 'consent': 3,
                             'legitimate uses, not expressly forbidden by law': 4, 'impact assessment': 5,
                             'security practices': 6, 'wrongful loss, wrongful gain': 7},
                         7: {'periodic audits ': 1, 'data protection impact assessment ': 2, 'data auditor': 3,
                             'data protection officer': 4, 'consent, lawful purpose': 5, 'internal security audits': 6,
                             'external audit': 7, 'reasonable security practices': 8, 'fraud risk management': 9,
                             'periodic legal audit': 10, 'pre-implementation, post implementation': 11},
                         8: {'copyright infringed': 1, 'patent is a product,  patent is a process': 2,
                             'infringment of registered trade mark ': 3, 'piracy of registered design': 4},
                         9: {'security controls ': 1, 'conformity assessment ': 2, 'risk management system ': 3,
                             'kyc': 4,
                             'due diligence report': 5, 'authorised agents confidentiality': 6,
                             'privacy of information': 7, 'security practices': 8},
                         10: {'web filtering ': 1, 'dlp ( data leakage prevention)': 2, 'use of cryptography': 3,
                              'security controls': 4, 'secure pin management': 5,
                              'protect cardholder data at terminals, reporting of fraud': 6, 'in-app notifications': 7,
                              'data processor ': 8, 'data auditor': 9, 'secure authentication processes': 10,
                              'encrypt card data immediately': 11, 'install tools': 12, 'e-kyc authentication': 13,
                              'aadhaar number\n': 14, 'unique identification authority': 15},
                         11: {'prohibit subliminal, manipulative ai techniques': 1,
                              'block ai scraping facial images': 2,
                              'harmful social scoring ai': 3, 'unauthorized access': 4, 'unlawful content': 5,
                              'introducing viruses or harmful code': 6}}

def get_question():
    li1 = []
    for item in data['question']:
        li2 = []
        for i in data["question"][item]:
            li2.append(question_choices_main[int(item)][i.lower()])
        tup = (item, li2)
        li1.append(tup)
    return li1

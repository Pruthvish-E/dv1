# import re
# import jinja2
# import pdfkit
# import PyPDF2
# # import fitz
# import pandas as pd
# import json
#
# from rest_framework import status
# from rest_framework.decorators import api_view
# from rest_framework.response import Response
#
# # from myapp.serializers import PercentageSerializer, PenaltyKeyPairSerializer
#
#
# def dummyGetQuestion():
#     # [(question ,[choice]),(question ,[choice,choice])]
#     temp = [(1, [1]), (3, [4]), (5, [5]), (6, [6]), (7, [2, 3, 4, 5, 6]), (8, [2, 3, 4, 5, 6, 7]),
#             (9, [2, 3, 4, 5, 6, 7, 8, 9, 10, 11]), (10, [2, 3, 4]), (11, [2, 3, 4, 5, 6, 7, 8]),
#             (12, [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]), (15, [1, 2, 3, 4, 5, 6])]
#     return temp
#
#
# def QuestionPenaltyObject(penalty, keyword, penalty_type):
#     return (penalty, int(keyword), [int(i) for i in penalty_type.split(',')])
#
#
# def precomuteQuestionPenalty():
#     df = pd.read_csv("files/Copy of Penalty - v.1 - QuestionKeyPenaltyKey Map.csv")
#     listOfQuestions = []
#     for index, item in df.iterrows():
#         listOfQuestions.append(QuestionPenaltyObject(item['Que no'], item['keyword'], item['Penalty type (key)']))
#     return listOfQuestions
#
#
# def percentage():
#     question_choices = get_scenario()
#     # print("question_choices",question_choices)
#     allQuestionsPenaltyObjects = precomuteQuestionPenalty()
#     totalQuestionsPenaltyObjects = len(allQuestionsPenaltyObjects)
#     seenPenaltyObjects = set()
#     i = 0
#     question_choices_filtered = []
#
#     # convert question_choices to tuple with single elements
#     for item in question_choices:
#         for i in item[1]:
#             question_choices_filtered.append((item[0], i))
#
#     # storing elements in seenPenaltyObjects
#     allQuestionsPenaltyObjects_filtered = []
#     for item in allQuestionsPenaltyObjects:
#         allQuestionsPenaltyObjects_filtered.append(item[:len(item) - 1])
#     # print("input ->", question_choices_filtered)
#
#     for element in question_choices_filtered:
#         if element in allQuestionsPenaltyObjects_filtered:
#             seenPenaltyObjects.add(element)
#
#     return int(len(seenPenaltyObjects) / totalQuestionsPenaltyObjects * 100)
#
#
# def generate_seenPenaltyObject_allQuestionsPenaltyObject():
#     question_choices = get_scenario()
#     allQuestionsPenaltyObjects = precomuteQuestionPenalty()
#     totalQuestionsPenaltyObjects = len(allQuestionsPenaltyObjects)
#     seenPenaltyObjects = set()
#     i = 0
#     question_choices_filtered = []
#
#     # convert question_choices to tuple with single elements
#     for item in question_choices:
#         for i in item[1]:
#             question_choices_filtered.append((item[0], i))
#
#     # storing elements in seenPenaltyObjects
#     allQuestionsPenaltyObjects_filtered = []
#     for item in allQuestionsPenaltyObjects:
#         allQuestionsPenaltyObjects_filtered.append(item[:len(item) - 1])
#     # print("input ->", question_choices_filtered)
#
#     for element in question_choices_filtered:
#         if element in allQuestionsPenaltyObjects_filtered:
#             seenPenaltyObjects.add(element)
#     return (seenPenaltyObjects, allQuestionsPenaltyObjects)
#
#
# def set_of_Penalty_object():
#     seenPenaltyObjects, allQuestionsPenaltyObjects = generate_seenPenaltyObject_allQuestionsPenaltyObject()
#     # print("seenPenaltyObjects",seenPenaltyObjects)
#     # print("allQuestionsPenaltyObject",allQuestionsPenaltyObjects)
#     notSelectedKeywords = allQuestionsPenaltyObjects[:]
#
#     validpenaltyset = set()
#     for element in seenPenaltyObjects:
#         for element1 in allQuestionsPenaltyObjects:
#             if element1[:len(element1) - 1] == element:
#                 notSelectedKeywords.remove(element1)
#     for i in notSelectedKeywords:
#         for k in i[-1]:
#             validpenaltyset.add(k)
#     # print("notSelectedKeywords",notSelectedKeywords)
#     # print(validpenaltyset)
#     return validpenaltyset
#
#
# def penalty_key_pair():
#     validPenaltySet = set_of_Penalty_object()
#     conversion_of_data = []
#     data = penalty_section_description()
#
#     maximum_value = 0
#     for i in validPenaltySet:
#         conversion_of_data.append((data[i][0], data[i][1]))
#         maximum_value += data[i][2]
#     return (conversion_of_data, number_to_words(min(maximum_value, 2500000000)))
#
#
# def penalty_section_description():
#     df = pd.read_csv("files/Penalty - v.1 - Penalty Table.csv")
#     section_description = []
#     for index, item in df.iterrows():
#         section_description.append((item['Section no.'], item['Penalty description'], item['Max Value ( Number )']))
#     return section_description
#
#
# def penalty_max():
#     total = 0
#     df = pd.read_csv("files/Penalty - v.1 - Penalty Table.csv")
#     for index, item in df.iterrows():
#         total += int(item['Max Value ( Number )'])
#     return total
#
#
# def get_scenario():
#     data = []
#     file = 'Scenario- v.1 - Scenario10.csv'
#     df = pd.read_csv(f"files/{file}")
#     for index, item in df.iterrows():
#         temp = (str(item['Question no.']), str(item['Keyword 1']), str(item['Keyword 2']), str(item['Keyword 3']),
#                 str(item['Keyword 4']), str(item['Keyword 5']), str(item['Keyword 6']), str(item['Keyword 7']),
#                 str(item['Keyword 8']), str(item['Keyword 9']), str(item['Keyword 10']), str(item['Keyword 11']),
#                 str(item['Keyword 12']), str(item['Keyword 13']), str(item['Keyword 14']), str(item['Keyword 15']))
#         list_of_data = []
#         temp_list = list()
#         if temp[0] != "nan":
#             for num in range(len(temp)):
#                 if num == 0:
#                     list_of_data.append(int(temp[num].replace('Question ', '')))
#                 else:
#                     if temp[num] != "nan":
#                         temp_list.append(num)
#             list_of_data.append(temp_list)
#         data.append(tuple(list_of_data))
#     return data
#
#
# def question_choices_with_values():
#     file = 'Penalty - v.1 - QuestionChoice Table.csv'
#     df = pd.read_csv(f"files/{file}")
#     data = []
#     for index, item in df.iterrows():
#         temp = (index, [str(item['Keyword 1']), str(item['Keyword 2']), str(item['Keyword 3']),
#                         str(item['Keyword 4']), str(item['Keyword 5']), str(item['Keyword 6']), str(item['Keyword 7']),
#                         str(item['Keyword 8']), str(item['Keyword 9']), str(item['Keyword 10']),
#                         str(item['Keyword 11']),
#                         str(item['Keyword 12']), str(item['Keyword 13']), str(item['Keyword 14']),
#                         str(item['Keyword 15'])])
#         cleaned_list = [item for item in temp if item != 'nan']
#         data.append(cleaned_list)
#
# def get_data(self):
# #     percentage
# #     pdf
# #     max penalty
# #     Response()
#     pass
# # create 3 api call
# @api_view(['GET'])
# def get_percentage(request):
#     perc = percentage()
#     max_pen = penalty_key_pair()[1]
#     serializer = PercentageSerializer({"percentage": perc, "max_penalty": max_pen})
#     return Response(serializer.data, status=status.HTTP_200_OK)
#
# @api_view(['GET'])
# def get_penalty_key_pair(request):
#     valid_penalties = penalty_key_pair()[0]
#     serializer = PenaltyKeyPairSerializer(valid_penalties, many=True)
#     return Response(serializer.data, status=status.HTTP_200_OK)
#
# @api_view(['POST'])
# def generate_pdf(request):
#     parse_pdf()
#     return Response({"message": "PDF generated successfully."}, status=status.HTTP_201_CREATED)
# def parse_pdf():
#     data = {
#         "gmail": "pradyumnadaware1@gmail.com",
#         "percentage": percentage(),
#         "valid_penalties": penalty_key_pair()[0],
#         "maximum_penalties": penalty_key_pair()[1]
#     }
#
#     template_loader = jinja2.FileSystemLoader(searchpath="templates/")
#     template_env = jinja2.Environment(loader=template_loader)
#     template = template_env.get_template("index.html")
#     output_text = template.render(data)
#
#     # Save the rendered HTML to a file
#     with open("index.html", "w") as file:
#         file.write(output_text)
#
#     path_to_wkhtmltopdf = r'C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe'
#     config = pdfkit.configuration(wkhtmltopdf=path_to_wkhtmltopdf)
#     pdfkit.from_file("index.html", "output.pdf", configuration=config)
#
#
# def authorization():
#     data = """
#     {
#         "username": "user123",
#         "password": "password"
#     }
#     """
#     auth_data = json.loads(data)
#     return auth_data
#
#
# def json_question_choices():
#     data = """
#     [
#         {"question_no": 1, "keyword_selected": ["Yes"]},
#         {"question_no": 2, "keyword_selected": ["No", "Yes"]}
#     ]
#     """
#     question_choices = json.loads(data)
#     return question_choices
#
#
# def json_output(percentage, max_penalty):
#     output_data = {
#         "percentage": percentage,
#         "max_penalty": max_penalty,
#         "pdf_link": "www.pdf"
#     }
#     return json.dumps(output_data, indent=4)
#
#
# def number_to_words(number):
#     units = {
#         100: "Hundred",
#         1000: "Thousand",
#         10000: "Ten Thousand",
#         100000: "Lakh",
#         10000000: "Crore"
#     }
#     result = []
#     for unit in sorted(units.keys(), reverse=True):
#         if number >= unit:
#             value = number // unit
#             result.append("{:} {}".format(value, units[unit]))
#             break
#
#     if not result:
#         result.append(str(number))
#     return ", ".join(result)
#
#
# parse_pdf()
#
# # set_of_Penalty_object()

from rest_framework import serializers
from .models import PDFModel


class PDFDocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = PDFModel
        fields = ['id', 'title', 'pdf_file', 'created_at']


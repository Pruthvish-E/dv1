from django.contrib import admin
from django.urls import path, include
from .views import upload_questions

urlpatterns = [
    path('admin/', admin.site.urls),
    path('upload-questions/', upload_questions),
]
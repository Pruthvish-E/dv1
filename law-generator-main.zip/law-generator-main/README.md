To run this application-
1) Enable virtual environment
2) Install libraries from requirements
3) Use python manage.py to run server
4) Go to url localhost/upload-questions/ and upload json data in json format
for eg:{
    "user_id": "user123",
    "email_id": "user123@example.com",
    "question": {
        "1": ["Yes"],
        "2": ["No"],
        "3": ["Yes"],
        "4": ["Yes"],
        "5": [
            "consent request notice in process",
            "explicit opt-in forms",
            "implicit consent through usage",
            "correction and erasure Of personal data"   
        ],
        "6": [],
        "7": [],
        "8": [],
        "9": [],
        "10": [],
        "11": []
    }
}
